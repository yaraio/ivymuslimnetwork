# Ivy Muslim Network

Complete static website export, including the latest six supplied testimonials.

## Files

- `dist/index.html`: main page, styling, embedded images, and page interactions.
- `dist/network/`: interactive globe, university data, vector logos, and bundled Three.js.
- `dist/services/`: service animations and supporting assets.
- `.openai/hosting.json`: existing ChatGPT Sites project configuration. Not needed for other hosts.

## Upload to GitHub

Unzip this archive and upload its contents to your repository. Preserve all folders. Do not upload only the ZIP.

## Run locally

From the repository directory:

```sh
python3 -m http.server 8000 --directory dist
```

Open http://localhost:8000. Use a web server rather than opening the HTML directly, because the globe loads JSON and JavaScript modules.

## Hosting

No package installation or build step is required. Serve `dist` as the website root. Some asset URLs begin with `/`, so hosting under a repository subpath requires adjusting those URLs. A custom domain serving at its root avoids that issue.

For GitHub Pages, either configure a deployment workflow to publish `dist`, or publish the contents of `dist` at the repository root using your chosen Pages setup. Uploading files to GitHub alone does not connect ivymuslim.org or change the existing live website.

Existing calendar links point to Cal.com. Keep the logo-source information and bundled dependency license notices. This export has no Git history, credentials, or private repository configuration.

Source commit: 3052bfba0da018e2faab4bb898aae3f4104945e3
